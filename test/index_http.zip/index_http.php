<?php
use RingCentral\Psr7\Response;
function handler($request, $context): Response{
	$requestBody = $request->getBody()->getContents();
	return new Response(
		202,
		array(
			"custom_header1" => "v1",
			"custom_header2" => ["v2", "v3"],
		),
		$requestBody
	);
}
