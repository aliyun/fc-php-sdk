<?php

$counter = 0;

function initializer($context) {
    global $counter;
    $counter += 1;
}

function handler($event, $context) {
    global $counter;
    $counter += 1;
    echo "fc_func_counter" . $counter . PHP_EOL;
    return $counter;
}
